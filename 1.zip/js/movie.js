function searchMovie() {
  $('#movie-list').html('');

  $.ajax({
    url: 'http://www.omdbapi.com/',
    type:'get',
    dataType:'json',
    data:{
      'apikey':'6db6408d',
      
      's':$('#search-input').val()
    },
    success:function(result) {
      if (result.Response=='True') {
        let movies = result.Search;
                  
        $.each(movies, function (i, data) {
          $('#movie-list').append(`
            <div class="col-md-4 mt-3">
              <div class="card">
                <img src="`+ data.Poster +`" class="card-img-top img-fluid">
                <div class="card-body">
                  <h5 class="card-title">`+data.Title+`</h5>
                  <h6 class="card-subtitle mb-2 text-muted">`+data.Year+`</h6>
                  <a href="#" data-id="`+data.imdbID+`" class="card-link show-detail" 
                  data-bs-toggle="modal" data-bs-target="#exampleModal">Show Details</a>
                </div>
              </div>
            </div>
          `)
        });

        $('#search-input').val('');
        
      }else{
        $('#movie-list').html(`<h1 class="text-center">`+result.Error+`</h1>`)
      }

    }
  });
  
}



$('#search-button').on('click', function () {
  searchMovie();
});

$('.nav-link').on('click', function() {
  $('#movie-list').html('');
  $('.nav-link').removeClass('active');
  $(this).addClass('active');

  let kategori = $(this).html();
  console.log(kategori);


  $.ajax({
    url: 'http://www.omdbapi.com/',
    type:'get',
    dataType:'json',
    data:{
      'apikey':'6db6408d',
      
      's':kategori
    },
    success:function(result) {
      if (result.Response=='True') {
        let movies = result.Search;
                  
        $.each(movies, function (i, data) {
          $('#movie-list').append(`
            <div class="col-md-4 mt-3">
              <div class="card">
                <img src="`+ data.Poster +`" class="card-img-top img-fluid">
                <div class="card-body">
                  <h5 class="card-title">`+data.Title+`</h5>
                  <h6 class="card-subtitle mb-2 text-muted">`+data.Year+`</h6>
                  <a href="#" data-id="`+data.imdbID+`" class="card-link show-detail" 
                  data-bs-toggle="modal" data-bs-target="#exampleModal">Show Details</a>
                </div>
              </div>
            </div>
          `)
        });

        $('#search-input').val('');
        
      }else{
        $('#movie-list').html(`<h1 class="text-center">`+result.Error+`</h1>`)
      }

    }
  });
  

  
  
})